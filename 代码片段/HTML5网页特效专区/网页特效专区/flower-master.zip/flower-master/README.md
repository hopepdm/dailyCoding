# flower
The flowers which are growing in canvas...

The path formula of love comes from the network.
爱心的路径公式来源于网络

Sorry for my Math...  0.0

It looks like 

![image](https://github.com/shalldie/flower/blob/master/img/GIF.gif)

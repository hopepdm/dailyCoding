

/**
 * toggleTips 				仿placeholder输入提示
 * @param  {[object]} e   	input元素
 * @param  {[string]} phc 	输入提示文字
 */
function toggleTips(e,phc) {
	var element = $(e);
	var placeholder = "<span class='placeholder-text'></span>";
	var placeholderContent = phc;

	//创建包裹目标input的元素,并插入提示文字
	element.wrap("<label></label>").after(placeholder);
	element.next(".placeholder-text").text(placeholderContent);

	//设置提示文字的css样式
	element.parent("label").css("position","relative");
	element.next(".placeholder-text").css({
		"position"	: "absolute",
		"left" 		: "5px",
		"top"		: "0",
		"cursor"	: "text",
		"color" 	: "#CCC"
	});

	element.focus(function(){
		var value = $(this).val();
		if(!value) {
			$(this).next(".placeholder-text").hide();
		}
	}).blur(function(){
		var value = $(this).val();
		if(!value) {
			$(this).next(".placeholder-text").show();
		}
	});
}
//删除上传的图片
function delete_pic(e){
	var $this = $(e);
	$this.parent().remove();
}
//删除上传的附件
function delete_attachment(e){
	var $this = $(e);
	$this.parent('span').remove();
}
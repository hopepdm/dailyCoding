/*globals HSIMP */HSIMP.language.en={translations:{main_title:"您的密码有多安全?(www.198zone.com)",top10k:"Top 10,000 Passwords by",version:"Version"}};
